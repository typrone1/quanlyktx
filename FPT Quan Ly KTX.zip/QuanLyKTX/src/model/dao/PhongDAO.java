package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;
import model.bean.Phong;

public class PhongDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyKTX";
	String userName = "sa";
	String password = "123";
	Connection connection;
	
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Phong> getListPhong() {
		connect();
		String sql=	String.format("SELECT * FROM Phong");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<Phong> list = new ArrayList<Phong>();
		Phong phong;
		try {
			while(rs.next()){
				phong = new Phong();
				phong.setMaPhong(rs.getString("MaPhong"));
				phong.setGiaTien(rs.getInt("GiaTien"));
				phong.setTang(rs.getInt("Tang"));
				phong.setSoNguoiOToiDa(rs.getInt("SoNguoiOToiDa"));
				phong.setGhiChu(rs.getString("GhiChu"));
				list.add(phong);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public Vector<Hashtable<String, String>> getListPhongTrong(int maTang, String loaiGioiTinh, int soLuongDaDangKy) {
		connect();
		String sql = "SELECT * FROM (SELECT Phong.MaPhong, MaHocKy, COUNT(MaDK) AS DaDangKy FROM DangKyLuuTru RIGHT JOIN Phong ON DangKyLuuTru.MaPhong = Phong.MaPhong GROUP BY Phong.MaPhong, MaHocKy) AS A INNER JOIN Phong ON A.MaPhong = Phong.MaPhong";
		if (maTang != 0 || !loaiGioiTinh.equals("") || soLuongDaDangKy > 0) {
			sql+= " WHERE";
			if (maTang != 0) {
				sql+= " Tang="+ maTang;
			}
			if (!loaiGioiTinh.equals("")) {
				if (maTang != 0) {
					sql+= " AND";
				}
				sql+= " LoaiGioiTinh=N'" + loaiGioiTinh+"'";
			}
			if (soLuongDaDangKy > 0) {
				if (maTang != 0 || !loaiGioiTinh.equals("")) {
					sql+= " AND";
				}
				sql+= " A.DaDangKy >= "+soLuongDaDangKy;
			}
		}
		sql += " ORDER BY Phong.MaPhong";
		System.out.println(sql);
		ResultSet rs = null;
		
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Vector<Hashtable<String, String>> records = new Vector<Hashtable<String,String>>();
		Hashtable<String, String> record;
		try {
			while(rs.next()){
				record = new Hashtable();
				record.put("MaPhong", rs.getString("MaPhong"));
				record.put("GiaTien", rs.getString("GiaTien"));
				record.put("Tang", rs.getString("Tang"));
				record.put("GiaTien", rs.getString("GiaTien"));
				record.put("SoNguoiOToiDa", rs.getString("SoNguoiOToiDa"));
				record.put("GhiChu", rs.getString("GhiChu"));
				record.put("DaDangKy", rs.getString("DaDangKy"));
				records.add(record);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return records;
	}
	public Vector<Hashtable<String, String>> getListPhongTrong() {
		connect();
		String sql = "SELECT * FROM (SELECT Phong.MaPhong, MaHocKy, COUNT(MaDK) AS DaDangKy FROM DangKyLuuTru RIGHT JOIN Phong ON DangKyLuuTru.MaPhong = Phong.MaPhong GROUP BY Phong.MaPhong, MaHocKy) AS A INNER JOIN Phong ON A.MaPhong = Phong.MaPhong ORDER BY Phong.MaPhong";
		ResultSet rs = null;
		
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Vector<Hashtable<String, String>> records = new Vector<Hashtable<String,String>>();
		Hashtable<String, String> record;
		try {
			while(rs.next()){
				record = new Hashtable();
				record.put("MaPhong", rs.getString("MaPhong"));
				record.put("GiaTien", rs.getString("GiaTien"));
				record.put("Tang", rs.getString("Tang"));
				record.put("GiaTien", rs.getString("GiaTien"));
				record.put("SoNguoiOToiDa", rs.getString("SoNguoiOToiDa"));
				record.put("GhiChu", rs.getString("GhiChu"));
				record.put("DaDangKy", rs.getString("DaDangKy"));
				records.add(record);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return records;
	}
}
