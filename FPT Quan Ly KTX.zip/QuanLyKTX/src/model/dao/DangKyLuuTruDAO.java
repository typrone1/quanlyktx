package model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import model.bean.DangKyLuuTru;
import model.bean.Phong;

public class DangKyLuuTruDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyKTX";
	String userName = "sa";
	String password = "123";
	Connection connection;
	
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public int dangKyLuuTru(DangKyLuuTru dangKyLuuTru) {
		connect();
		String sql=	String.format("INSERT INTO DangKyLuuTru(MaPhong,MaSV,NgayDangKy,MaHocKy,TinhTrangLuuTru,TinhTrangXuLy,DaNopTien,SoThangLuuTru) "+
					" VALUES (?,?,GETDATE(),?,?,?,?,?)");
		try {
			DateFormat format = new SimpleDateFormat("yyyy/mm/dd");
			PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, dangKyLuuTru.getMaPhong());
			stmt.setString(2, dangKyLuuTru.getMaSV());
			stmt.setString(3, dangKyLuuTru.getMaHocKy());
			stmt.setString(4, dangKyLuuTru.getTinhTrangLuuTru());
			stmt.setString(5, dangKyLuuTru.getTinhTrangXuLy());
			stmt.setInt(6, dangKyLuuTru.getDaNopTien());
			stmt.setInt(7, dangKyLuuTru.getSoThangLuuTru());
			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
		    rs.next();
		    return rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}
	public DangKyLuuTru getChiTietDangKyPhong(int maDK) {
		connect();
		String sql=	String.format("SELECT * FROM DangKyLuuTru WHERE MaDK = " + maDK);
		ResultSet rs = null;
		DangKyLuuTru dangKyLuuTru = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			
			if (rs.next()){
				dangKyLuuTru = new DangKyLuuTru();
				dangKyLuuTru.setMaDK(rs.getInt("MaDK"));
				dangKyLuuTru.setDaNopTien(rs.getInt("DaNopTien"));
				dangKyLuuTru.setMaHocKy(rs.getString("MaHocKy"));
				dangKyLuuTru.setMaPhong(rs.getString("MaPhong"));
				dangKyLuuTru.setMaSV(rs.getString("MaSV"));
				dangKyLuuTru.setSoThangLuuTru(rs.getInt("SoThangLuuTru"));
				dangKyLuuTru.setTinhTrangLuuTru(rs.getString("TinhTrangLuuTru"));
				dangKyLuuTru.setTinhTrangXuLy(rs.getString("TinhTrangXuLy"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return dangKyLuuTru;
	}
	public ArrayList<DangKyLuuTru> getListDangKyPhong() {
		connect();
		String sql=	String.format("SELECT * FROM DangKyLuutru");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DangKyLuuTru> list = new ArrayList<DangKyLuuTru>();
		DangKyLuuTru dangKyLuuTru;
		try {
			while(rs.next()){
				dangKyLuuTru = new DangKyLuuTru();
				dangKyLuuTru.setMaDK(rs.getInt("MaDK"));
				dangKyLuuTru.setMaSV(rs.getString("MaSV"));
				dangKyLuuTru.setDaNopTien(rs.getInt("DaNopTien"));
				dangKyLuuTru.setMaHocKy(rs.getString("MaHocKy"));
				dangKyLuuTru.setMaPhong(rs.getString("MaPhong"));
				dangKyLuuTru.setNgayDangKy(rs.getDate("NgayDangKy"));
				dangKyLuuTru.setTinhTrangXuLy(rs.getString("TinhTrangXuLy"));
				list.add(dangKyLuuTru);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public int duyetDangKyPhong(int maDK) {
		connect();
		String sql=	String.format("UPDATE DangKyLuuTru "+
					" SET TinhTrangXuLy = 1 WHERE MaDK = '%s'", maDK);
		try {
			Statement stmt = connection.createStatement();
			return stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	
	public int traPhong(int maDK) {
		connect();
		String sql=	String.format("UPDATE DangKyLuuTru "+
					" SET TinhTrangLuuTru = 0 WHERE MaDK = '%s'", maDK);
		try {
			Statement stmt = connection.createStatement();
			return stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}
}
