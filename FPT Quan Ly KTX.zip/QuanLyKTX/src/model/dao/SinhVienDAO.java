package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Set;

import model.bean.SinhVien;

public class SinhVienDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyKTX";
	String userName = "sa";
	String password = "123";
	Connection connection;
	
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public int themSinhVien(SinhVien sinhVien) {
		connect();
		try {
			PreparedStatement stmt;
			String sql = "INSERT INTO SinhVien(HoTen, NgaySinh, GioiTinh, CMND) VALUES (?,?,?,?)";
			stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, sinhVien.getHoTen());
			stmt.setDate(2, new java.sql.Date(sinhVien.getNgaySinh().getTime()));
			stmt.setString(3, sinhVien.getGioiTinh());
			stmt.setString(4, sinhVien.getCmnd());
			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
		    rs.next();
		    return rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int doiMatKhau(String maSV, String matKhauMoi) {
		connect();
		String sql=	String.format("UPDATE SinhVien "+
					" SET MatKhau = '%s' WHERE TaiKhoan = '%s'", matKhauMoi, maSV);
		try {
			Statement stmt = connection.createStatement();
			return stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}
	public boolean checkLogin(String tenDangNhap, String matKhau) {
		connect();
		String sql=	String.format("SELECT * FROM SinhVien WHERE TaiKhoan = '%s' AND MatKhau = '%s'", tenDangNhap, matKhau);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public SinhVien getThongTinSinhVien(String taiKhoan) {
		System.out.println("OK");
		connect();
		String sql=	String.format("SELECT * FROM SinhVien WHERE TaiKhoan = '%s'", taiKhoan);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		SinhVien sinhVien = new SinhVien();
		try {
			while(rs.next()){
				sinhVien.setMaSV(rs.getInt("MaSV"));
				sinhVien.setCmnd(rs.getString("CMND"));
				sinhVien.setHoTen(rs.getString("HoTen"));
				sinhVien.setNgaySinh(rs.getDate("NgaySinh"));
				sinhVien.setSdt(rs.getString("SDT"));
				sinhVien.setQueQuan(rs.getString("QueQuan"));
				sinhVien.setMaTruong(rs.getString("MaTruong"));
				sinhVien.setGioiTinh(rs.getString("GioiTinh"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sinhVien;
	}
	
	public SinhVien findSinhVien(String maSV) {
		System.out.println("OK");
		connect();
		String sql=	String.format("SELECT * FROM SinhVien WHERE MaSV = '%s'", maSV);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		SinhVien sinhVien = new SinhVien();
		try {
			while(rs.next()){
				sinhVien.setMaSV(rs.getInt("MaSV"));
				sinhVien.setCmnd(rs.getString("CMND"));
				sinhVien.setHoTen(rs.getString("HoTen"));
				sinhVien.setNgaySinh(rs.getDate("NgaySinh"));
				sinhVien.setSdt(rs.getString("SDT"));
				sinhVien.setQueQuan(rs.getString("QueQuan"));
				sinhVien.setMaTruong(rs.getString("MaTruong"));
				sinhVien.setGioiTinh(rs.getString("GioiTinh"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sinhVien;
		
	}
	public SinhVien getSinhVien(String MaSV) {
		connect();
		String sql=	String.format("SELECT * FROM SinhVien Where MaSV="+MaSV);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		SinhVien sinhVien;
		try {
			if (rs.next()){
				sinhVien = new SinhVien();
				sinhVien.setMaSV(rs.getInt("MaSV"));
				sinhVien.setHoTen(rs.getString("HoTen"));
				sinhVien.setGioiTinh(rs.getString("GioiTinh"));
				sinhVien.setNgaySinh(rs.getDate("NgaySinh"));
				sinhVien.setCmnd(rs.getString("CMND"));
				sinhVien.setGioiTinh(rs.getString("GioiTinh"));
				sinhVien.setSdt(rs.getString("SDT"));
				sinhVien.setQueQuan(rs.getString("QueQuan"));
				sinhVien.setMaTruong(rs.getString("MaTruong"));
				return sinhVien;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<SinhVien> getListSinhVien() {
		connect();
		String sql=	String.format("SELECT * FROM SinhVien");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<SinhVien> list = new ArrayList<SinhVien>();
		SinhVien sinhVien;
		try {
			while(rs.next()){
				sinhVien = new SinhVien();
				sinhVien.setMaSV(rs.getInt("MaSV"));
				sinhVien.setHoTen(rs.getString("HoTen"));
				sinhVien.setGioiTinh(rs.getString("GioiTinh"));
				sinhVien.setNgaySinh(rs.getDate("NgaySinh"));
				sinhVien.setCmnd(rs.getString("CMND"));
				sinhVien.setGioiTinh(rs.getString("GioiTinh"));
				sinhVien.setSdt(rs.getString("SDT"));
				sinhVien.setQueQuan(rs.getString("QueQuan"));
				sinhVien.setMaTruong(rs.getString("MaTruong"));
				list.add(sinhVien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
