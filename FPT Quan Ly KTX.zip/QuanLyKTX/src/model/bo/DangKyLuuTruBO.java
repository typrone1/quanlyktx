package model.bo;

import java.util.ArrayList;

import model.bean.DangKyLuuTru;
import model.dao.DangKyLuuTruDAO;

public class DangKyLuuTruBO {
	private DangKyLuuTruDAO dangKyLuuTruDAO = new DangKyLuuTruDAO();
	public int dangKyLuuTru(DangKyLuuTru dangKyLuuTru) {
		return dangKyLuuTruDAO.dangKyLuuTru(dangKyLuuTru);
	}
	
	public ArrayList<DangKyLuuTru> getListDangKyPhong() {
		return dangKyLuuTruDAO.getListDangKyPhong();
	}
	public DangKyLuuTru getChiTietDangKyPhong(int maDK) {
		return dangKyLuuTruDAO.getChiTietDangKyPhong(maDK);
	}
	public int duyetDangKyPhong(int maDK) {
		return dangKyLuuTruDAO.duyetDangKyPhong(maDK);
	}
	public int traPhong(int maDK) {
		return dangKyLuuTruDAO.traPhong(maDK);
	}
}
