package model.bo;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;

import model.bean.Phong;
import model.dao.PhongDAO;

public class PhongBO {
	PhongDAO phongDAO = new PhongDAO();
	public ArrayList<Phong> getListPhong() {
		return phongDAO.getListPhong();
	}
	public Vector<Hashtable<String, String>> getListPhongTrong() {
		return phongDAO.getListPhongTrong();
	}
	public Vector<Hashtable<String, String>> getListPhongTrong(int maTang, String loaiGioiTinh, int soLuongDaDangKy) {
		return phongDAO.getListPhongTrong(maTang, loaiGioiTinh, soLuongDaDangKy);
	}
}
