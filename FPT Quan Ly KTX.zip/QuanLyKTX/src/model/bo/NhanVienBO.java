package model.bo;

import model.dao.NhanVienDAO;

public class NhanVienBO {
	NhanVienDAO nhanVienDAO = new NhanVienDAO();
	public boolean checkLogin(String tenDangNhap, String matKhau) {
		return nhanVienDAO.checkLogin(tenDangNhap, matKhau);
	}
}
