package model.bo;

import java.util.ArrayList;

import model.bean.SinhVien;
import model.dao.SinhVienDAO;

public class SinhVienBO {
	SinhVienDAO sinhVienDAO = new SinhVienDAO();
	public int themSinhVien(SinhVien sinhVien) {
		return sinhVienDAO.themSinhVien(sinhVien);
	}
	public boolean checkLogin(String tenDangNhap, String matKhau) {
		return sinhVienDAO.checkLogin(tenDangNhap, matKhau);
	}
	public SinhVien getThongTinSinhVien(String taiKhoan) {
		return sinhVienDAO.getThongTinSinhVien(taiKhoan);
	}
	public SinhVien findSinhVien(String maSV) {
		return sinhVienDAO.findSinhVien(maSV);
	}
	public int doiMatKhau(String maSV, String matKhauMoi) {
		return sinhVienDAO.doiMatKhau(maSV, matKhauMoi);
	}
	public SinhVien getSinhVien(String MaSV) {
		return sinhVienDAO.getSinhVien(MaSV);
	}
	public ArrayList<SinhVien> getListSinhVien() {
		return sinhVienDAO.getListSinhVien();
	}
}
