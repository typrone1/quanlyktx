package model.bean;

public class Phong {
	private String maPhong;
	private String maLoaiPhong;
	private int giaTien;
	private String khu;
	private int tang;
	private int soNguoiOToiDa;
	private String ghiChu;
	public Phong() {
		super();
	}
	public String getMaPhong() {
		return maPhong;
	}
	public void setMaPhong(String maPhong) {
		this.maPhong = maPhong;
	}
	public String getMaLoaiPhong() {
		return maLoaiPhong;
	}
	public void setMaLoaiPhong(String maLoaiPhong) {
		this.maLoaiPhong = maLoaiPhong;
	}
	public int getGiaTien() {
		return giaTien;
	}
	public void setGiaTien(int giaTien) {
		this.giaTien = giaTien;
	}
	public String getKhu() {
		return khu;
	}
	public void setKhu(String khu) {
		this.khu = khu;
	}
	public int getTang() {
		return tang;
	}
	public void setTang(int tang) {
		this.tang = tang;
	}
	public int getSoNguoiOToiDa() {
		return soNguoiOToiDa;
	}
	public void setSoNguoiOToiDa(int soNguoiOToiDa) {
		this.soNguoiOToiDa = soNguoiOToiDa;
	}
	public String getGhiChu() {
		return ghiChu;
	}
	public void setGhiChu(String ghiChu) {
		this.ghiChu = ghiChu;
	}
	
}
