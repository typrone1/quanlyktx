package model.bean;

import java.util.Date;

public class DangKyLuuTru {
	private int maDK;
	private String maPhong;
	private int soThangLuuTru;
	private String maSV;
	private Date ngayDangKy;
	private Date ngayTraPhong;
	private String maHocKy;
	private String tinhTrangXuLy;
	private String tinhTrangLuuTru;
	private int daNopTien;
	public DangKyLuuTru() {
		super();
	}
	public String getMaPhong() {
		return maPhong;
	}
	public void setMaPhong(String maPhong) {
		this.maPhong = maPhong;
	}
	public int getSoThangLuuTru() {
		return soThangLuuTru;
	}
	public void setSoThangLuuTru(int soThangLuuTru) {
		this.soThangLuuTru = soThangLuuTru;
	}
	public String getMaSV() {
		return maSV;
	}
	public void setMaSV(String maSV) {
		this.maSV = maSV;
	}
	public Date getNgayDangKy() {
		return ngayDangKy;
	}
	public void setNgayDangKy(Date ngayDangKy) {
		this.ngayDangKy = ngayDangKy;
	}
	public Date getNgayTraPhong() {
		return ngayTraPhong;
	}
	public void setNgayTraPhong(Date ngayTraPhong) {
		this.ngayTraPhong = ngayTraPhong;
	}
	public String getMaHocKy() {
		return maHocKy;
	}
	public void setMaHocKy(String maHocKy) {
		this.maHocKy = maHocKy;
	}
	public String getTinhTrangXuLy() {
		return tinhTrangXuLy;
	}
	public void setTinhTrangXuLy(String tinhTrangXuLy) {
		this.tinhTrangXuLy = tinhTrangXuLy;
	}
	public String getTinhTrangLuuTru() {
		return tinhTrangLuuTru;
	}
	public void setTinhTrangLuuTru(String tinhTrangLuuTru) {
		this.tinhTrangLuuTru = tinhTrangLuuTru;
	}
	public int getDaNopTien() {
		return daNopTien;
	}
	public void setDaNopTien(int daNopTien) {
		this.daNopTien = daNopTien;
	}
	public void setMaDK(int maDK) {
		this.maDK = maDK;
	}
	public int getMaDK() {
		return maDK;
	}
	
	
}
