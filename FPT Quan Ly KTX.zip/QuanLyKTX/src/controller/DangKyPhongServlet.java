package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.bean.DangKyLuuTru;
import model.bean.SinhVien;
import model.bo.DangKyLuuTruBO;
import model.bo.SinhVienBO;

public class DangKyPhongServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DangKyPhongServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String maPhong = (String) request.getParameter("mp");
		HttpSession session = request.getSession();
		if (session.getAttribute("sessionSinhVien") == null) {
			response.sendRedirect("DangNhapSinhVienServlet");
			return;
		}
		request.setAttribute("maPhong", maPhong);
		SinhVienBO sinhVienBO = new SinhVienBO();
		String taiKhoanSV = (String) session.getAttribute("sessionSinhVien");
		SinhVien sinhVien = sinhVienBO.getThongTinSinhVien(taiKhoanSV);
		request.setAttribute("sinhVien", sinhVien);
		RequestDispatcher dispatcher = request.getRequestDispatcher("dangKyLuuTru.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		DangKyLuuTru dangKyLuuTru = (DangKyLuuTru) session.getAttribute("dangKyLuuTru");
		System.out.println(dangKyLuuTru);
		DangKyLuuTruBO dangKyLuuTruBO = new DangKyLuuTruBO();
		int maDangKy = dangKyLuuTruBO.dangKyLuuTru(dangKyLuuTru);
		request.setAttribute("maDangKy", maDangKy);
		RequestDispatcher dispatcher = request.getRequestDispatcher("xacNhanDangKy.jsp");
		dispatcher.forward(request, response);
	}
}
