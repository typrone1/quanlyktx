package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DangKyLuuTru;
import model.bean.SinhVien;
import model.bo.DangKyLuuTruBO;
import model.bo.SinhVienBO;

/**
 * Servlet implementation class ChiTietSinhVienServlet
 */
public class ChiTietSinhVienServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ChiTietSinhVienServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		SinhVienBO sinhVienBO = new SinhVienBO();
		String maSV = request.getParameter("MaSV");
		SinhVien sinhVien = sinhVienBO.getSinhVien(maSV);
		request.setAttribute("sinhVien", sinhVien);
		DangKyLuuTruBO dangKyLuuTruBO = new DangKyLuuTruBO();
		ArrayList<DangKyLuuTru> listDangKyLuuTru = dangKyLuuTruBO.getListDangKyPhong();
		request.setAttribute("listDangKyLuuTru", listDangKyLuuTru);
		RequestDispatcher dispatcher = request.getRequestDispatcher("chiTietSinhVien.jsp");
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
