package controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.SinhVien;
import model.bo.SinhVienBO;

/**
 * Servlet implementation class DangKyThanhVienServlet
 */
public class DangKyThanhVienServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DangKyThanhVienServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("dangKySinhVien.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		SinhVien sv = new SinhVien();
		sv.setHoTen(request.getParameter("hoTen"));
		sv.setCmnd(request.getParameter("cmnd"));
		String dateStr = request.getParameter("ngaySinh");
		Date date = null;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
			System.out.println(date);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sv.setNgaySinh(date);
		sv.setGioiTinh(request.getParameter("gioiTinh"));
		SinhVienBO sinhVienBO = new SinhVienBO();
		int maSV = sinhVienBO.themSinhVien(sv);
		if (maSV > 0) {
			request.setAttribute("msg", "Thêm thành công  " + maSV);
		} else {
			request.setAttribute("msg", "Thêm thất bại");
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("dangKySinhVien.jsp");
		dispatcher.forward(request, response);

	}

}
