package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.bo.NhanVienBO;
import model.bo.SinhVienBO;

public class DangNhapSinhVienServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DangNhapSinhVienServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("dangNhap.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String tenDangNhap = request.getParameter("username");
		String matKhau = request.getParameter("password");
		SinhVienBO sinhVienBO = new SinhVienBO();
		if (sinhVienBO.checkLogin(tenDangNhap, matKhau)) {
			HttpSession session = request.getSession();
			session.setAttribute("sessionSinhVien", tenDangNhap);
			response.sendRedirect("DanhSachPhongDangKyServlet");
			return;
		} else {
			request.setAttribute("thongBao", "Ä�Äƒng nháº­p khÃ´ng thÃ nh cÃ´ng");
		}
		RequestDispatcher rd = request.getRequestDispatcher("dangNhap.jsp");
		rd.forward(request, response);
	}

}
