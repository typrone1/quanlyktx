package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.Phong;
import model.bo.PhongBO;

/**
 * Servlet implementation class DanhSachPhongDangKyServlet
 */
public class DanhSachPhongDangKyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DanhSachPhongDangKyServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PhongBO phongBO = new PhongBO();
		Vector<Hashtable<String, String>> listPhong = phongBO.getListPhongTrong();
		request.setAttribute("listPhong", listPhong);
		RequestDispatcher dispatcher = request.getRequestDispatcher("danhSachPhongDangKy.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
