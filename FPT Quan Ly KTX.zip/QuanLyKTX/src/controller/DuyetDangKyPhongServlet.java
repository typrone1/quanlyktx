package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DangKyLuuTru;
import model.bean.SinhVien;
import model.bo.DangKyLuuTruBO;
import model.bo.SinhVienBO;

/**
 * Servlet implementation class DuyetDangKyPhongServlet
 */
public class DuyetDangKyPhongServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DuyetDangKyPhongServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("mdk") == null) {
			response.sendRedirect("DanhSachDangKyPhongServlet");
			return;
		}
		String maDangKy = request.getParameter("mdk");
		DangKyLuuTruBO dangKyLuuTruBO = new DangKyLuuTruBO();
		DangKyLuuTru dangKyLuuTru = dangKyLuuTruBO.getChiTietDangKyPhong(Integer.parseInt(maDangKy));
		SinhVienBO sinhVienBO = new SinhVienBO();
		SinhVien sinhVien = sinhVienBO.findSinhVien(dangKyLuuTru.getMaSV());
		request.setAttribute("dangKyLuuTru", dangKyLuuTru);
		request.setAttribute("sinhVien", sinhVien);
		System.out.println(sinhVien.getMaSV());
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("duyetDangKyPhong.jsp");
		requestDispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		DangKyLuuTruBO dangKyLuuTruBO = new DangKyLuuTruBO();
		int maDK = Integer.parseInt(request.getParameter("mdk"));
		if (dangKyLuuTruBO.duyetDangKyPhong(maDK) > 0) {
			request.setAttribute("thongBao", "Duyệt thành công");
		} else {
			request.setAttribute("thongBao", "Duyệt không thành công");
		}
		DangKyLuuTru dangKyLuuTru = dangKyLuuTruBO.getChiTietDangKyPhong(maDK);
		request.setAttribute("dangKyLuuTru", dangKyLuuTru);
		SinhVienBO sinhVienBO = new SinhVienBO();
		SinhVien sinhVien = sinhVienBO.findSinhVien(dangKyLuuTru.getMaSV());
		request.setAttribute("sinhVien", sinhVien);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("duyetDangKyPhong.jsp");
		requestDispatcher.forward(request, response);
	}

}
