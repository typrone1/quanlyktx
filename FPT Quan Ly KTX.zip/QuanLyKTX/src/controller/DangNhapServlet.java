package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.bo.NhanVienBO;

public class DangNhapServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DangNhapServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("dangNhap.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String tenDangNhap = request.getParameter("username");
		String matKhau = request.getParameter("password");
		NhanVienBO nhanVienBO = new NhanVienBO();
		if (nhanVienBO.checkLogin(tenDangNhap, matKhau)) {
			HttpSession session = request.getSession();
			session.setAttribute("sessionNhanVien", tenDangNhap);
			response.sendRedirect("TrangQuanTriServlet");
			return;
		} else {
			request.setAttribute("thongBao", "Đăng nhập thành công");
		}
		RequestDispatcher rd = request.getRequestDispatcher("dangNhap.jsp");
		rd.forward(request, response);
	}
}
