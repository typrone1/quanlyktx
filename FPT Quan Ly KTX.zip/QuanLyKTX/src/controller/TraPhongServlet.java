package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DangKyLuuTru;
import model.bo.DangKyLuuTruBO;

public class TraPhongServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TraPhongServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int maDK = Integer.parseInt(request.getParameter("mdk"));
		DangKyLuuTruBO dangKyLuuTruBO = new DangKyLuuTruBO();
		DangKyLuuTru dangKyLuuTru = dangKyLuuTruBO.getChiTietDangKyPhong(maDK);
		request.setAttribute("dangKyLuuTru", dangKyLuuTru);
		request.getRequestDispatcher("xacNhanTraPhong.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int maDK = Integer.parseInt(request.getParameter("mdk"));
		DangKyLuuTruBO dangKyLuuTruBO = new DangKyLuuTruBO();
		dangKyLuuTruBO.traPhong(maDK);
		response.sendRedirect("DanhSachDangKyPhongServlet");
	}

}
