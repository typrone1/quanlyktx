package controller;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bo.PhongBO;

/**
 * Servlet implementation class QuanLyPhongServlet
 */
public class QuanLyPhongServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public QuanLyPhongServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PhongBO phongBO = new PhongBO();
		Vector<Hashtable<String, String>> listPhong = null;
		if (request.getParameter("loaiGioiTinh") != null || request.getParameter("tang") != null
				|| request.getParameter("soLuongDangKy") != null) {
			String loaiGioiTinh = "";
			int maTang = 0;
			int soLuong = 0;
			try {
				loaiGioiTinh = request.getParameter("loaiGioiTinh");
				maTang = Integer.parseInt(request.getParameter("tang"));
				soLuong = Integer.parseInt(request.getParameter("soLuongDangKy"));
			} catch (Exception e) {
			}
			listPhong = phongBO.getListPhongTrong(maTang, loaiGioiTinh, soLuong);
		} else {
			listPhong = phongBO.getListPhongTrong();
		}
		request.setAttribute("listPhong", listPhong);
		request.getRequestDispatcher("quanLyPhong.jsp").forward(request, response);
	}

}
