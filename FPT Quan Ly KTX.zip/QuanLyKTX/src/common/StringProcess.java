package common;

public class StringProcess {
	public static String getVaildString(String s) {
		if(s==null) return "";
		return s;
	}
	
}
