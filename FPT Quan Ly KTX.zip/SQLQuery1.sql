CREATE DATABASE QuanLyKTX
GO
USE QuanLyKTX
GO

CREATE TABLE NhanVien(
	MaNV nvarchar(12) primary key,
	Username nvarchar(50) unique,
	Password nvarchar(50),
	HoTen nvarchar(50)
)

INSERT INTO NhanVien(MaNV, Username, Password, HoTen) VALUES ('NV001', 'admin', 'admin', N'Quản Lý')
CREATE TABLE Truong(
	MaTruong nvarchar(12) primary key,
	TenTruong nvarchar(50)
)
INSERT INTO Truong(MaTruong, TenTruong) VALUES ('DHDN', N'Đại học Đà Nẵng')
INSERT INTO Truong(MaTruong, TenTruong) VALUES ('DTU', N'Đại học Duy Tân')
INSERT INTO Truong(MaTruong, TenTruong) VALUES ('UTE', N'Đại học Sư phạm Kỹ Thuật')
INSERT INTO Truong(MaTruong, TenTruong) VALUES ('CDCNTT', N'Cao đẳng Công nghệ thông tin')
CREATE TABLE SinhVien
(
	MaSV int identity(1,1) primary key,
	HoTen nvarchar(50),
	TaiKhoan varchar(50),
	MatKhau nvarchar(50),
	NgaySinh date,
	CMND nvarchar(12),
	GioiTinh nvarchar(3),
	SDT nvarchar(12),
	QueQuan nvarchar(50),
	MaTruong nvarchar(12) FOREIGN KEY REFERENCES Truong(MaTruong)
)
INSERT INTO SinhVien(HoTen, TaiKhoan, MatKhau, NgaySinh, CMND, GioiTinh, SDT, QueQuan, MaTruong)
VALUES (N'Nguyễn Văn A', 'admin', 'admin', '1997-1-1', '123456789', N'Nam', '01234567890', N'Quảng Nam','DHDN')

CREATE TABLE Phong(
	MaPhong nvarchar(12) primary key,
	LoaiGioiTinh nvarchar(5),
	GiaTien int,
	Khu varchar(5),
	Tang int,
	SoNguoiOToiDa int,
	GhiChu nvarchar(50)
)

INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A101', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A102', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A103', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A104', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A105', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A106', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A107', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A108', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A109', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A110', 'Nam', 500, 1, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A201', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A202', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A203', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A204', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A205', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A206', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A207', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A208', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A209', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A210', 'Nam', 500, 2, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A301', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A302', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A303', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A304', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A305', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A306', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A307', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A308', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A309', N'Nữ', 500, 3, 8, '')
INSERT INTO Phong(MaPhong, LoaiGioiTinh, GiaTien, Tang, SoNguoiOToiDa, GhiChu)
VALUES ('A310', N'Nữ', 500, 3, 8, '')
CREATE TABLE HocKy(
	MaHocKy varchar(6) primary key,
	TenHocKy nvarchar(50),
)

INSERT INTO HocKy(MaHocKy, TenHocKy)
VALUES ('118', '118')
INSERT INTO HocKy(MaHocKy, TenHocKy)
VALUES ('218', '218')
INSERT INTO HocKy(MaHocKy, TenHocKy)
VALUES ('318', '318')
CREATE TABLE DangKyLuuTru(
	MaDK int identity(1,1) PRIMARY KEY,
	MaPhong nvarchar(12) FOREIGN KEY REFERENCES Phong(MaPhong),
	MaSV int FOREIGN KEY REFERENCES SinhVien(MaSV),
	NgayDangKy date,
	NgayTraPhong date,
	MaHocKy varchar(6) FOREIGN KEY REFERENCES HocKy(MaHocKy),
	TinhTrangLuuTru int,
	TinhTrangXuLy int,
	DaNopTien int,
	SoThangLuuTru int,
)

CREATE TABLE ThoiGian(
	MaThoiGian nvarchar(12),
	NgayTao date,
	primary key(MaThoiGian)
)

CREATE TABLE ChiSoDien(
	MaThoiGian nvarchar(12) FOREIGN KEY REFERENCES ThoiGian(MaThoiGian),
	MaPhong nvarchar(12) FOREIGN KEY REFERENCES Phong(MaPhong),
	ChiSoDienCu int,
	ChiSoDienMoi int,
	SoDienTieuThu int,
	NgayNhapChiSo date,
	GiaDien int,
	ThanhTien decimal(10,2),
	DaNopTien int,
	primary key(MaPhong, MaThoiGian)
)

CREATE TABLE HomThuGopY(
	MaGopY nvarchar(12) primary key,
	TenNguoiGui nvarchar(50),
	NoiDung text,
	NgayGui date,
	GhiChu nvarchar(100)
)